
const bookContainer = document.getElementById('book-container');

const books = [
    {
        id: 1,
        name:'Javascript for beginners',
        description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas, voluptate.',
        author:'John Doe',
        price: 20,
        slug:'javascript-for-beginners',
        image:'https://m.media-amazon.com/images/I/51Zymoq7UnL._SX218_BO1,204,203,200_QL40_FMwebp_.jpg'
    },
    {
        id: 2,
        name:'Html for beginners',
        description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas, voluptate.',
        author:'manzi Doe',
        price: 40,
        slug:'html-for-beginners',
        image:'https://m.media-amazon.com/images/I/51Zymoq7UnL._SX218_BO1,204,203,200_QL40_FMwebp_.jpg'
    },
    {
        id: 3,
        name:'React for beginners',
        description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas, voluptate.',
        author:'John Man',
        price: 20,
        slug:'react-for-beginners',
        image:'https://m.media-amazon.com/images/I/51Zymoq7UnL._SX218_BO1,204,203,200_QL40_FMwebp_.jpg'
    },
    {
        id: 4,
        name:'css for beginners',
        description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas, voluptate.',
        author:'John Doe',
        price: 20,
        slug:'css-for-beginners',
        image:'https://m.media-amazon.com/images/I/51Zymoq7UnL._SX218_BO1,204,203,200_QL40_FMwebp_.jpg'
    },
    {
        id: 5,
        name:'Job for beginners',
        description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas, voluptate.',
        author:'John Doe',
        price: 20,
        slug:'job-for-beginners',
        image:'https://m.media-amazon.com/images/I/51Zymoq7UnL._SX218_BO1,204,203,200_QL40_FMwebp_.jpg'
    },
]

function displayBooks(){
    books.map((book)=>{
        const bookElement = document.createElement('div');
        const bookImage = document.createElement('img');
        const bookName = document.createElement('h2');
        const bookAuthor = document.createElement('p');
        const bookDescription = document.createElement('p');
        const bookPrice = document.createElement('p');

        bookImage.src = book.image;
        bookName.textContent = book.name;
        bookAuthor.textContent = `Author: ${book.author}`;
        bookDescription.textContent = book.description;
        bookPrice.textContent = `Price: $${book.price.toFixed(2)}`;

        bookElement.appendChild(bookImage);
        bookElement.appendChild(bookName);
        bookElement.appendChild(bookAuthor);
        bookElement.appendChild(bookDescription);
        bookElement.appendChild(bookPrice);

        bookContainer.appendChild(bookElement);

    })
}
